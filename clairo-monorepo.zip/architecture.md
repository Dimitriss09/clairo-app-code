
# Architecture

- **Mobile (React Native + Expo, TypeScript)** single codebase for iOS/Android.
- **Backend (Node + Express + Prisma + Socket.IO)** with PostgreSQL, Redis, and MinIO (S3‑compatible).
- **Admin (Next.js + TypeScript)** for user/content/subscription management.
- **Sync**: offline‑first on device (SQLite via Expo SQLite) with write‑ahead queue. Server applies LWW with field‑level merge; socket updates for real‑time.
- **Collaboration**: Operational Transform (OT) over WebSockets for rich‑text blocks; fallback to LWW.
- **Payments**: Apple/Google IAP on mobile (stub provider for local) and Stripe for web/admin (test keys).

See `docs/er-diagram.mmd` and `api/openapi.yaml`.
