
import { Router } from 'express';
import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();
export const adminRouter = Router();
adminRouter.get('/users', async (_req,res)=>{
  const users = await prisma.user.findMany({ select:{id:true,email:true,name:true,suspended:true}});
  res.json(users);
});
