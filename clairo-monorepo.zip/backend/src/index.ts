
import express from 'express';
import http from 'http';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import { PrismaClient } from '@prisma/client';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { Server } from 'socket.io';
import YAML from 'yamljs';
import swaggerUi from 'swagger-ui-express';

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

const prisma = new PrismaClient();
const JWT_SECRET = process.env.JWT_SECRET || 'dev';
app.use(cors());
app.use(helmet());
app.use(express.json({limit: '2mb'}));
app.use(morgan('dev'));

// OpenAPI docs
const openapi = YAML.load(process.cwd() + '/api/openapi.yaml');
app.use('/docs', swaggerUi.serve, swaggerUi.setup(openapi));

// Auth helpers
function signToken(userId: string) { return jwt.sign({ sub: userId }, JWT_SECRET, { expiresIn: '7d' }); }
async function auth(req: any, res: any, next: any) {
  const h = req.headers.authorization || ''; const t = h.startsWith('Bearer ') ? h.slice(7) : null;
  if (!t) return res.status(401).json({error:'unauthorized'});
  try { const d:any = jwt.verify(t, JWT_SECRET); req.userId = d.sub; next(); } catch { return res.status(401).json({error:'invalid_token'}); }
}

import { adminRouter } from './admin';

// Routes
app.post('/auth/signup', async (req, res)=>{
  const {email, password, name} = req.body;
  const hash = await bcrypt.hash(password, 10);
  const user = await prisma.user.create({data:{email, passwordHash:hash, name}});
  res.json({ token: signToken(user.id), user });
});
app.post('/auth/login', async (req,res)=>{
  const {email,password} = req.body; const user = await prisma.user.findUnique({where:{email}});
  if (!user) return res.status(400).json({error:'invalid_credentials'});
  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) return res.status(400).json({error:'invalid_credentials'});
  res.json({ token: signToken(user.id), user });
});

app.get('/me', auth, async (req:any,res)=>{
  const user = await prisma.user.findUnique({where:{id:req.userId}});
  res.json(user);
});

app.get('/workspaces', auth, async (req:any,res)=>{
  const w = await prisma.workspace.findMany({ where: { OR:[{ownerId:req.userId},{ permissions:{ some:{ userId:req.userId } }}]}});
  res.json(w);
});
app.post('/workspaces', auth, async (req:any,res)=>{
  const ws = await prisma.workspace.create({data:{name:req.body.name, ownerId:req.userId}});
  res.json(ws);
});
app.get('/pages/:id', auth, async (req:any,res)=>{
  const p = await prisma.page.findUnique({where:{id:req.params.id}});
  res.json(p);
});
app.post('/pages', auth, async (req:any,res)=>{
  const p = await prisma.page.create({data:{...req.body, createdById:req.userId}});
  io.to(p.workspaceId).emit('page:new', p);
  res.json(p);
});
app.put('/pages/:id', auth, async (req:any,res)=>{
  const p = await prisma.page.update({where:{id:req.params.id}, data:req.body});
  io.to(p.workspaceId).emit('page:updated', p);
  res.json(p);
});

// Simple health
app.get('/healthz', (_req,res)=>res.json({ok:true}));
app.use('/admin', adminRouter);

io.on('connection', (socket)=>{
  socket.on('joinWorkspace', (id)=> socket.join(id));
  socket.on('ot:apply', async ({pageId, op})=>{
    // pseudo: store op as new version and broadcast
    io.emit('ot:op', {pageId, op});
  });
});

const port = process.env.PORT || 4000;
server.listen(port, ()=> console.log('API on :'+port));
