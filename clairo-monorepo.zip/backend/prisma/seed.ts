
import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();
async function main() {
  const demo = await prisma.user.upsert({
    where: { email: 'demo@clairo.app' },
    update: {},
    create: { email: 'demo@clairo.app', name: 'Demo User', passwordHash: '$2a$10$JjC8oal.0H85a6ixLJ5xL.2hC3rO5XoB1m0t7GJ6QqU9h2s8z4e3a' /* password: demo1234 */ }
  });
  const ws = await prisma.workspace.create({ data: { name: 'Demo Notebook', ownerId: demo.id }});
  await prisma.page.create({ data: { title:'Welcome to Clairo', content:{type:'doc', blocks:[{type:'paragraph', text:'Hello from seed!'}]}, workspaceId: ws.id, tags:['welcome'], createdById: demo.id } });
  console.log('Seeded:', { demo, ws });
}
main().finally(()=>prisma.$disconnect());
