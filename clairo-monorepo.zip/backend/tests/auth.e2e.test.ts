
import request from 'supertest';
import { execSync } from 'child_process';
let server:any;
beforeAll(()=>{
  server = require('../dist/index.js');
});
test('signup and login', async ()=>{
  const email = `user${Date.now()}@clairo.app`;
  const res = await request('http://localhost:4000').post('/auth/signup').send({email, password:'demo1234', name:'Test'});
  expect(res.status).toBe(200);
  const token = res.body.token;
  const me = await request('http://localhost:4000').get('/me').set('Authorization', `Bearer ${token}`);
  expect(me.status).toBe(200);
});
