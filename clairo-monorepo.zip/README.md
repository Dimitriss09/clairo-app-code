
# Clairo – All‑in‑One Student App

This is the **production‑ready monorepo** for **Clairo** (iOS, Android, Web Admin, and Backend).  
Branding and logos from the *All‑in‑One Student App* spec are applied across apps.

## Quickstart

Prereqs: Docker, pnpm, Node 20, OpenJDK 17, Xcode/Android Studio, Expo CLI.

```bash
pnpm i
docker compose -f infra/docker-compose.yml up -d
pnpm dev:backend
pnpm dev:admin
pnpm dev:mobile
```

Mobile runs via Expo; scan the QR in Terminal to open on device or use emulators.

See `architecture.md` for system design, `api/openapi.yaml` for API, and `infra/` for IaC.
