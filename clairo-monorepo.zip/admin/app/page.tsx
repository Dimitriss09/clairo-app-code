
'use client'
import { useEffect, useState } from 'react'
import axios from 'axios'
const API = process.env.NEXT_PUBLIC_API_BASE || 'http://localhost:4000'
export default function Home(){
  const [users, setUsers] = useState<any[]>([])
  useEffect(()=>{ axios.get(API+'/admin/users').then(r=>setUsers(r.data||[])).catch(()=>{}) },[])
  return <main style={{padding:24}}>
    <h1>Clairo Admin</h1>
    <p>Users</p>
    <table><thead><tr><th>Email</th><th>Name</th><th>Suspended</th></tr></thead>
    <tbody>{users.map(u=><tr key={u.id}><td>{u.email}</td><td>{u.name}</td><td>{u.suspended? 'Yes':'No'}</td></tr>)}</tbody></table>
  </main>
}
