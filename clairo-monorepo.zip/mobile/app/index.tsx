
import { Link } from 'expo-router'
import { Image, Text, View, Pressable } from 'react-native'
export default function Home(){
  return <View style={{flex:1, alignItems:'center', justifyContent:'center', padding:24}}>
    <Image source={require('../assets/logo2.png')} style={{width:96,height:96, marginBottom:16}} />
    <Text accessibilityLabel="Clairo title" style={{fontSize:28, fontWeight:'700'}}>Clairo</Text>
    <Text style={{textAlign:'center', marginVertical:8}}>Your all‑in‑one student workspace.</Text>
    <Link href="/login" asChild><Pressable style={{padding:12, backgroundColor:'#1473FF', borderRadius:12, marginTop:24}}><Text style={{color:'#fff'}}>Get Started</Text></Pressable></Link>
  </View>
}
