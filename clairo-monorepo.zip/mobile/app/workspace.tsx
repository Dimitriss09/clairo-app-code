
import { useEffect, useState } from 'react'
import { View, Text, TextInput, FlatList, Pressable } from 'react-native'
import axios from 'axios'
const API = process.env.EXPO_PUBLIC_API_BASE || 'http://localhost:4000'
export default function Workspace(){
  const [pages,setPages]=useState<any[]>([])
  const [title,setTitle]=useState('New Page')
  async function load(){
    const ws = await axios.get(API+'/workspaces', { headers:{ Authorization:`Bearer ${globalThis.token}` }})
    const wid = ws.data[0]?.id
    if (!wid) return
    const page = await axios.post(API+'/pages', { title:'Quick Note', content:{text:'Hello'}, workspaceId: wid, tags:[] }, { headers:{ Authorization:`Bearer ${globalThis.token}` }})
    setPages([page.data])
  }
  useEffect(()=>{ load() },[])
  return <View style={{flex:1,padding:16}}>
    <Text style={{fontSize:22, fontWeight:'700'}}>Workspace</Text>
    <FlatList data={pages} keyExtractor={i=>i.id} renderItem={({item})=>(
      <View style={{padding:12, borderWidth:1, borderRadius:8, marginVertical:6}}>
        <Text>{item.title}</Text>
      </View>
    )} />
  </View>
}
