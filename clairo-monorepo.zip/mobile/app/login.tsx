
import { useState } from 'react'
import { View, TextInput, Text, Pressable } from 'react-native'
import { useRouter } from 'expo-router'
import axios from 'axios'
const API = process.env.EXPO_PUBLIC_API_BASE || 'http://localhost:4000'
export default function Login(){
  const [email,setEmail]=useState('demo@clairo.app')
  const [password,setPassword]=useState('demo1234')
  const r = useRouter()
  async function submit(){
    const res = await axios.post(API+'/auth/login',{email,password})
    globalThis.token = res.data.token
    r.replace('/workspace')
  }
  return <View style={{padding:24, gap:12}}>
    <Text style={{fontSize:28, fontWeight:'700'}}>Clairo</Text>
    <TextInput placeholder="Email" value={email} onChangeText={setEmail} style={{borderWidth:1,padding:12,borderRadius:8}} />
    <TextInput placeholder="Password" secureTextEntry value={password} onChangeText={setPassword} style={{borderWidth:1,padding:12,borderRadius:8}} />
    <Pressable accessibilityLabel="Sign in" onPress={submit} style={{padding:12, backgroundColor:'#1473FF', borderRadius:12}}><Text style={{color:'#fff', textAlign:'center'}}>Sign in</Text></Pressable>
  </View>
}
